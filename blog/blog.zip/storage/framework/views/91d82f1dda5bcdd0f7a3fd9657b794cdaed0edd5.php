

<?php $__env->startSection('content'); ?>
<div class="container center_div" class="text-center">
    <h1><?php echo e($post->title); ?></h1>
  <br>
  <div class="col">
    <div class="card-block p-2">
        <h2>Author</h2>
        <span>made by <b><?php echo e($post->user->name); ?></b> ,created on  <?php echo e($post->created_at); ?></span>
        <h3>Title</h3>
        <?php echo e($post->title); ?>

        <h4 class="card-title">Description</h4>
        <p class="m-3 p-2"><?php echo e($post->description); ?></p>
    </div>
</div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\Laravel_Blog\Laravel_Blog_Pro\blog\resources\views/posts/show.blade.php ENDPATH**/ ?>