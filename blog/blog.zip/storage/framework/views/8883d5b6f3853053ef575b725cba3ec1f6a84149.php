

<?php $__env->startSection('content'); ?>
<?php if(Session::has('success')): ?>
<p style="color: blueviolet"><?php echo e(Session::get('success')); ?></p>
<?php endif; ?>
<div class="clearfix">
    <h2 style="text-align: center">Blog Posts</h2>
    
  </div>
<div class="container">

    <?php // check if a user is authonticated ?>
    <?php if(auth::check()): ?>
    <div>
        <a role="button" class="btn btn-outline-primary" href="/posts/create" >Create post</a>
    </div>     
    <?php endif; ?>

    <br>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
            <?php // check if a user is loged in and they have posts ?>
            <?php if(isset(Auth::user()->id) && Auth::user()->id == $post->user_id): ?>

            <a style="width: 100px;position: absolute;
            right: 0;"  class="btn btn-success float-right" 
            href="/posts/<?php echo e($post->slug); ?>/edit">Update</a>
            <br>
            <br>
            <form  action="posts/<?php echo e($post->id); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
            <button style="background-color: red;" onclick="return confirm('Are you sure you want to delete this post?');" class="btn btn-success float-right" >Delete</button>
            </form>
                
            <?php endif; ?>
            
            <div class="row no-gutters">
                <div class="col-auto">                   
            <img  src=" <?php echo e(asset('images/' . $post->image_path)); ?>" class="float-left mr-4 mt-2" style="float:left;clear:right;margin-left:10px;height:300px;position:relative;top:-10px">
                </div>
                    <div class="col">
                        <div class="card-block p-2">
                            <h2>Author</h2>
                            <span>made by <b><?php echo e($post->user->name); ?></b> ,created on  <?php echo e($post->created_at); ?></span>
                            <h3>Title</h3>
                            <?php echo e($post->title); ?>

                            <h4 class="card-title">Description</h4>
                            <p class="m-3 p-2"><?php echo e($post->description); ?></p>
                            <a href="/posts/<?php echo e($post->slug); ?>" class="btn btn-primary ">Keep Reading</a>
                        </div>
                    </div>
            </div>
        </div>
            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\Laravel_Blog\Laravel_Blog_Pro\blog\resources\views/posts/index.blade.php ENDPATH**/ ?>