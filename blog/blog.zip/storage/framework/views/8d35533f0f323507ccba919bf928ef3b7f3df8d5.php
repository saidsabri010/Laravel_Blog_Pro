

<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div class="container center_div" class="text-center">
    <h1>Create a Post</h1>
  <br>
    <form action="/posts" method="POST" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
            <div class="form-group">
              <label>Title :</label>
              <input type="text" name="title" class="form-control" placeholder="Title">
            </div>
              <div class="form-floating">
                <label for="floatingTextarea">Description :</label>
                <textarea name="description" class="form-control" placeholder="Leave a comment here" id="floatingTextarea"></textarea>
              </div>
              <br>
              <div class="form-floating">
                <label for="file" class="form-label" >Select a File : </label>
                <input name="image" type="file" class="form-control" />
              </div>
              <br>

            <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\Laravel_Blog\Laravel_Blog_Pro\blog\resources\views/posts/create.blade.php ENDPATH**/ ?>